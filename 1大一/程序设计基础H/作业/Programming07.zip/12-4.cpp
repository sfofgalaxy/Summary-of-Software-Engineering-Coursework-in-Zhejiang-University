#include <stdio.h>
#include <stdlib.h>
void SortIntegerArray(int *p,int m,int n){
	int *t,*s,temp;
	t=p+m;s=p+n;
	temp=*t;*t=*s;*s=temp;
}
int main(){
	int *array;
	int i,j,n,index;
	scanf("%d",&n);
	array=(int *)malloc(n*sizeof(int));
	for(i=0;i<n;i++){
		scanf("%d",array+i);
	}
	for(i=0;i<n-1;i++){
		index=i;
		for(j=i+1;j<n;j++){
			if(*(array+j)<*(array+index)){
				index=j;
			}
		}
		SortIntegerArray(array,i,index);
	}
	for(i=0;i<n-1;i++){
		printf("%d ",*(array+i));
	}
	printf("%d\n",array[n-1]);
}
