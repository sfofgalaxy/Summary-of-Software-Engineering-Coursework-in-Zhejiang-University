#include <stdio.h>
#include <stdlib.h>
int totalnum;
int *Tabulate(int *array,int n){
	int *p;int j;
	p=(int *)malloc(n*sizeof(int));
	for(j=0;j<n;j++){
		*(p+j)=0;
	}
	for(j=0;j<totalnum;j++){
		*(p+*(array+j))=*(p+*(array+j))+1;
	}
	return p;
}  
int main(){
	int i,min,max;
	int array[1000];
	int *ans;
	char c;
	totalnum=0;
	scanf("%d",&array[totalnum]);
	min=array[totalnum];max=array[totalnum];
		totalnum++;
		scanf("%c",&c);
	while(c!='\n'){
		scanf("%d",&array[totalnum]);
		if(min>array[totalnum]){min=array[totalnum];
		}
		if(max<array[totalnum]){max=array[totalnum];
		}
		totalnum++;
		scanf("%c",&c);
	}
	ans=(int *)malloc(sizeof(int)*(max-min+1));
	for(i=0;i<totalnum;i++){
		array[i]-=min;
	}
	ans=Tabulate(array,max-min+1);
	for(i=0;i<max-min+1;i++){
		if(*(ans+i)!=0){
			printf("%d:%d\n",min+i,*(ans+i));
		}
	}
	return 0;
}

