#include <stdio.h>
#include <stdlib.h>

int *IndexArray(int n){
	int *p;int j;
	p=(int *)malloc(n*sizeof(int));
	for(j=0;j<n;j++){
		*(p+j)=j;
	}
	return p;
} 
int main(){
	int i,n;
	int *ip;
	scanf("%d",&n);
	ip=IndexArray(n);
	for(i=0;i<n-1;i++){
		printf("%d ",*(ip+i));
	}
	printf("%d\n",*(ip+n-1));
}
