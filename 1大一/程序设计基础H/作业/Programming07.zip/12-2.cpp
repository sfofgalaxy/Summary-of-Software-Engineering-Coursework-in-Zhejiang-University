#include <stdio.h>
#include <string.h>

void GetDate(int *dp,int *mp,int *yp){
	printf("Day=%d\n",*dp);
	printf("Month=%d\n",*mp);
	printf("Year=%d\n",*yp);
	return;
}
int main(){
	char p[20];
	char *t;
	int day,month,year,i;
	printf("Enter a date as dd-mmm-yy:");
	scanf("%s",&p);
	t=p;day=0;month=0;year=0;
	while(*t!='-'){
		day=day*10+*t-48;
		t++;
	}
	t++;
	switch(*t){
		case 'F':month=2;break;
		case 'O':month=10;break;
		case 'N':month=11;break;
		case 'S':month=9;break;
		case 'D':month=12;break;
		case 'M':t++;t++;if(*t=='r')month=3;
								else month=5;t--;t--;break;
		case 'A':t++;if(*t=='p')month=4;
							else month=8;t--;break;
		case 'J':t++;if(*t=='a')month=1;
					else{t++;if(*t=='n')month=6;else month=7;t--;
					}t--;break;
	}
	t=t+4;
	for(i=1;i<=2;i++){
		year=year*10+*t-48;
		t++;
	}
	GetDate(&day,&month,&year);
	return 0;
}

