#include<stdio.h> 
int RemoveDuplicates(int array[],int n){
	int i,j,count;
	for(i=0,count=n;i<n-1;i++){
		while(array[i]==array[i+1]&&array[i]){
			count--;
			for(j=i+1;j<n-1;j++){
				array[j]=array[j+1];
			}
			array[n-1]=0;
		}
	}
	return count;
}
