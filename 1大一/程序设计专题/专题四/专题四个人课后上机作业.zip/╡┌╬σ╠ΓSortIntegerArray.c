#include <stdio.h>

void SortIntegerArray(int *array,int n)
{
	int temp,i,j,k,l;
	for(i=1;i<n;i++){
		for(j=0;j<i;j++){
			if(array[i]<=array[j]){
				temp = array[i]; 
				for(k=i-1;k>=j;k--)array[k+1]=array[k];
				array[j]=temp;
				break; 
			}
		}
	}
} 

