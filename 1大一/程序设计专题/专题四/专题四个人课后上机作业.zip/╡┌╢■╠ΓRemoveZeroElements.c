#include<stdio.h> 
int RemoveZeroElements(int *array��int n){
	int i,count;
	for(i=0,count=0;i<n;i++){
		if(array[i]!=0){
			array[count]=array[i];
			array[i]=0;
			count++;
		}
	}
	return count;
}
