#include<stdio.h>
#include<time.h>
int main(void)
{
	shuffle();
}
void shuffle(void)
{
	int a[52];
	int index, tmp, i;  
    srand(time(NULL));
	for(i=0;i<52;i++)a[i]=i+1;  
    for(i=0; i<52; i++)  
    {
        index=rand()%(52-i)+i;     
        if(index!=i)  
        {  
            tmp=a[i];  
            a[i]=a[index];  
            a[index]=tmp;  
        }  
    }
    for(i=0;i<52;i++)printf("%d ",a[i]);
} 
