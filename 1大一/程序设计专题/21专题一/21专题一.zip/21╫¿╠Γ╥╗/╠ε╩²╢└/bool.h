#ifndef _BOOL_H
#define _BOOL_H

#define TRUE 1
#define FALSE 0

void produce_sudoku(void);
void fill_num(int x,int y);
int judge(void);

#endif 
