#ifndef _FUN_H
#define _FUN_H


void partition_1(int *p,int n,int num_of_array);


#endif 
